//initializing my matrial design plugins

$(document).ready(function(){
    
$('.button-collapse').sideNav();


//slider
$('.slider').slider();

//modal
$('.modal').modal({
  opacity:.1
});


//collapse
 $('.collapsible').collapsible();

 //parallax
    $('.parallax').parallax();

 //scrollspy
 $('.scrollspy').scrollSpy();

});

