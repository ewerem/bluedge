<?php 

$pdo = new pdo('mysql:host=localhost;dbname=bedge', 'root', '');

date_default_timezone_set('Africa/Lagos');

/*
T#;Bx*rzmgTB // bluedgec_bedge -db // bluedgec_blue -dbuser
*/

?>